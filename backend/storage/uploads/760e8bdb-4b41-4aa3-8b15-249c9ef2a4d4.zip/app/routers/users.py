from fastapi import APIRouter
router=APIRouter(prefix='/users')
@router.get('/')
def list_users():
    return {'users':[]}

@router.post('/')
def create_user():
    return {'status':'created'}
